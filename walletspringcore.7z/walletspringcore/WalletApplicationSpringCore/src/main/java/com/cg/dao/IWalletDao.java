package com.cg.dao;

import java.util.List;

import com.cg.bean.Customer;
import com.cg.bean.Transaction;
import com.cg.exception.WalletApplicationException;

public interface IWalletDao {

	public Customer createAccount (Customer customer); 
	public double showBalance(int customerId) throws WalletApplicationException;
	public boolean deposit(int customerId, double amount) throws WalletApplicationException;
	public boolean withdraw(int customerId, double amount) throws WalletApplicationException;
	public boolean fundTransfer(int senderCustomerId,int reciverCustomerId,double amount) throws WalletApplicationException;
	List<Transaction> printTransaction(int customerId);

	
}
