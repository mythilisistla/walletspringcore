package com.cg.bean;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;

@Entity

public class Customer {

	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE,generator="myseq")
	@SequenceGenerator(name="myseq",sequenceName="customerseq",initialValue=1,allocationSize=1)
	@Column(length=10)
	int customerId;
	@Column(length=25)
	String customerName;
	@Column(length=20)
	String dateOfBirth;
	@Column(length=15)
	String phone;
	@Column(length=20)
	String email;
	@Column(length=20)
	String address;
	@OneToOne(cascade=CascadeType.ALL)
	@JoinColumn(name="accountid")
	Account account;
	@OneToMany(cascade=CascadeType.ALL,mappedBy="customer")
	List<Transaction> transationList;
	
	
	
	public Customer() {
		super();
		
	}


	public Customer(int customerId, String customerName, String dateOfBirth, String phone, String email,
			String address, Account account, List<Transaction> transationList) {
		super();
		this.customerId = customerId;
		this.customerName = customerName;
		this.dateOfBirth = dateOfBirth;
		this.phone = phone;
		this.email = email;
		this.address = address;
		this.account = account;
		this.transationList = transationList;
	}
	
	
	public Customer(String customerName, String dateOfBirth, String phone, String email, String address,
			Account account, List<Transaction> transationList) {
		super();
		this.customerName = customerName;
		this.dateOfBirth = dateOfBirth;
		this.phone = phone;
		this.email = email;
		this.address = address;
		this.account = account;
		this.transationList = transationList;
	}


	public int getCustomerId() {
		return customerId;
	}
	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public String getDateOfBirth() {
		return dateOfBirth;
	}
	public void setDateOfBirth(String dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public Account getAccount() {
		return account;
	}
	public void setAccount(Account account) {
		this.account = account;
	}
	public List<Transaction> getTransationList() {
		return transationList;
	}
	public void setTransationList(List<Transaction> transationList) {
		this.transationList = transationList;
	}


	@Override
	public String toString() {
		return "Customer [customerId=" + customerId + ", customerName=" + customerName + ", dateOfBirth=" + dateOfBirth
				+ ", phone=" + phone + ", email=" + email + ", address=" + address + ", account=" + account
				+ ", transationList=" + transationList + "]";
	}
	
	

}
