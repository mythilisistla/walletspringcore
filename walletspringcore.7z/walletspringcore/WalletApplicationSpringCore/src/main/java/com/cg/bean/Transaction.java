package com.cg.bean;

import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;

@Entity
public class Transaction {

	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE,generator="myseq")
	@SequenceGenerator(name="myseq",sequenceName="transseq",initialValue=100,allocationSize=1)
	@Column(length=10)
	int transactionId;
	@Column(length=20)
	String transactionType;
	@Column(length=40)
	String transactionDate;
	@Column(length=20)
	int toAccountNo;
	double amount;
	@ManyToOne(cascade=CascadeType.ALL)
	@JoinColumn(name="custid")
	Customer customer;
	
	
	public Transaction() {
		super();
		// TODO Auto-generated constructor stub
	}


	public Transaction(int transactionId, String transactionType, String transactionDate, int toAccountNo,
			double amount) {
		super();
		this.transactionId = transactionId;
		this.transactionType = transactionType;
		this.transactionDate = transactionDate;
		this.toAccountNo = toAccountNo;
		this.amount = amount;
	}

	

	public Transaction(String transactionType, String transactionDate, int toAccountNo, double amount,
			Customer customer) {
		super();
		this.transactionType = transactionType;
		this.transactionDate = transactionDate;
		this.toAccountNo = toAccountNo;
		this.amount = amount;
		this.customer = customer;
	}


	public int getTransactionId() {
		return transactionId;
	}


	public void setTransactionId(int transactionId) {
		this.transactionId = transactionId;
	}


	public String getTransactionType() {
		return transactionType;
	}


	public void setTransactionType(String transactionType) {
		this.transactionType = transactionType;
	}


	public String getTransactionDate() {
		return transactionDate;
	}


	public void setTransactionDate(String transactionDate) {
		this.transactionDate = transactionDate;
	}


	public long getToAccountNo() {
		return toAccountNo;
	}


	public void setToAccountNo(int toAccountNo) {
		this.toAccountNo = toAccountNo;
	}


	public double getAmount() {
		return amount;
	}


	public void setAmount(double amount) {
		this.amount = amount;
	}
	
	

}
