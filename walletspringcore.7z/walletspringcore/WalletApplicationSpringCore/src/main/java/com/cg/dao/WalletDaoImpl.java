package com.cg.dao;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import com.cg.bean.Account;
import com.cg.bean.Customer;
import com.cg.bean.Transaction;
import com.cg.exception.WalletApplicationException;
import com.cg.ui.Client;
import com.cg.util.WalletUtility;

public class WalletDaoImpl implements IWalletDao {

	EntityManagerFactory entityManagerFactory;
	EntityManager entityManager;
	EntityTransaction entityTransaction;
	
	public WalletDaoImpl() {
		entityManagerFactory = Persistence.createEntityManagerFactory("jpa");
		entityManager = entityManagerFactory.createEntityManager();
		entityTransaction = entityManager.getTransaction();
	}
	
	static List<Transaction> transactionList = new ArrayList<>();
	
	public Customer createAccount(Customer customer) {
		
		entityTransaction.begin();
		entityManager.persist(customer);
		entityTransaction.commit();
		return customer;
	}

	public double showBalance(int customerId) throws WalletApplicationException {
		
		Customer customer;
		try {
			customer = entityManager.find(Customer.class, customerId);
			return customer.getAccount().getBalance();
		} catch (Exception e) {
			
		  throw new WalletApplicationException("invalid customer id");
		}
		
	
	}

	public boolean deposit(int customerId, double amount)  throws WalletApplicationException {
		
		entityTransaction.begin();
		
		Customer customer=null;
		try {
			customer = entityManager.find(Customer.class, customerId);
		} catch (Exception e) {
		
			throw new WalletApplicationException("invalid customer id");
		}
		
		Account account = customer.getAccount();
		double bal = account.getBalance()+amount;
		account.setBalance(bal);
		customer.setAccount(account);
		
		List<Transaction> transactionList = new ArrayList<>();
		if(customer.getTransationList()!=null)
		transactionList = customer.getTransationList();
		
		Transaction transaction = new Transaction("deposit",new Date().toString(),0,amount,customer);
		transactionList.add(transaction);
		customer.setTransationList(transactionList);
		entityManager.merge(customer);
		entityTransaction.commit();
		return true;
	}

	public boolean withdraw(int customerId, double amount) throws WalletApplicationException {
	
		entityTransaction.begin();
		Customer customer = entityManager.find(Customer.class, customerId);
		Account account = customer.getAccount();
		if(account.getBalance()<amount) {
			return false;
		}
		else {
			double bal = account.getBalance()-amount;
			account.setBalance(bal);
			customer.setAccount(account);
			
			List<Transaction> transactionList = new ArrayList<>();
			if(customer.getTransationList()!=null)
			transactionList = customer.getTransationList();
			
			Transaction transaction = new Transaction("withdrawn",new Date().toString(),0,amount,customer);
			transactionList.add(transaction);
			customer.setTransationList(transactionList);
			
			
			entityManager.merge(customer);
		}
		
		entityTransaction.commit();
		
		
		return true;
	}

	public boolean fundTransfer(int senderCustomerId,int reciverCustomerId,double amount) throws WalletApplicationException {

		entityTransaction.begin();
		Customer senderCustomer = entityManager.find(Customer.class,senderCustomerId);
		Customer reciverCustomer = entityManager.find(Customer.class,reciverCustomerId);
		
	    if(senderCustomer.getAccount().getBalance()<amount) {
	    	return false;
	    }
	    else {
	    	Account senderAccount = senderCustomer.getAccount();
	    	Account reciverAccount = reciverCustomer.getAccount();
	    	
	    	double senderBalance = senderAccount.getBalance();
	    	double reciverBalance = reciverAccount.getBalance();
	    	
	    	senderBalance = senderBalance - amount;
	    	reciverBalance = reciverBalance + amount;
	    	
	        senderAccount.setBalance(senderBalance);
	        reciverAccount.setBalance(reciverBalance);
	        
	        senderCustomer.setAccount(senderAccount);
	        reciverCustomer.setAccount(reciverAccount);
	        
	        List<Transaction> senderTransactionList = new ArrayList();
	        senderTransactionList = senderCustomer.getTransationList();
	        Transaction senderTransaction = new Transaction("ftrans",new Date().toString(),reciverCustomerId,amount,senderCustomer);
	        senderTransactionList.add(senderTransaction);
	        senderCustomer.setTransationList(senderTransactionList);
	        
	        List<Transaction> reciverTransactionList = new ArrayList();
	        reciverTransactionList = reciverCustomer.getTransationList();
	        Transaction reciverTransaction = new Transaction("frecive",new Date().toString(),senderCustomerId,amount,reciverCustomer);
	        reciverTransactionList.add(reciverTransaction);
	        reciverCustomer.setTransationList(reciverTransactionList);
	        
	        
	        entityManager.merge(senderCustomer);
	        entityManager.merge(reciverCustomer);
	        
	    }
	    entityTransaction.commit();
		return false;
	}

	public List<Transaction> printTransaction(int customerId) {
		Customer customer = entityManager.find(Customer.class, customerId);
		return customer.getTransationList();
	}
	
	public void addTransaction(Transaction transaction) {
		
	}

}
