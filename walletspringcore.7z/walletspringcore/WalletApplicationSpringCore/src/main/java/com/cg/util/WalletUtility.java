package com.cg.util;

import java.util.HashMap;
import java.util.Map;

import com.cg.bean.Account;
import com.cg.bean.Customer;

public class WalletUtility {
	
	public static Map<Integer, Customer> customerMap = new HashMap<>();
	static
	{
	   customerMap.put(123,new Customer(123,"varalaxmi","12/06/1997","8186077969","varalaxmi@gmail.com","nizamabad",new Account(12345,0.0),null));
	
	}


}
