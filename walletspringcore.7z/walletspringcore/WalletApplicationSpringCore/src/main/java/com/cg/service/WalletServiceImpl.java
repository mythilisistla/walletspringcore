package com.cg.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.cg.bean.Customer;
import com.cg.bean.Transaction;
import com.cg.dao.IWalletDao;
import com.cg.dao.WalletDaoImpl;
import com.cg.exception.WalletApplicationException;
/**
 * @author vmummala
 *
 */
@Component
public class WalletServiceImpl implements IWalletService {

	@Autowired
	IWalletDao iWalletDao;
	
	public Customer createAccount(Customer customer) {
		
		return iWalletDao.createAccount(customer);
	}

	public double showBalance(int customerId) throws WalletApplicationException {
		
		return iWalletDao.showBalance(customerId);
	}

	public boolean deposit(int customerId, double amount)  throws WalletApplicationException {
		
		return iWalletDao.deposit(customerId, amount);
	}

	public boolean withdraw(int customerId, double amount) throws WalletApplicationException {
		
		return iWalletDao.withdraw(customerId, amount);
	}

	public boolean fundTransfer(int senderCustomerId,int reciverCustomerId,double amount) throws WalletApplicationException {
		
		return iWalletDao.fundTransfer(senderCustomerId,reciverCustomerId, amount);
	}

	public List<Transaction> printTransaction(int customerId) {
		
		return iWalletDao.printTransaction(customerId);
	}

}
