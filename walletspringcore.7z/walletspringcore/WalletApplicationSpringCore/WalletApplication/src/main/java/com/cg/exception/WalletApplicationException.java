package com.cg.exception;

public class WalletApplicationException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public WalletApplicationException() {
		super();
	
	}

	public WalletApplicationException(String message) {
		super(message);
		
	}

	
}
