package com.cg.service;

import java.util.List;

import com.cg.bean.Customer;
import com.cg.bean.Transaction;
import com.cg.dao.IWalletDao;
import com.cg.dao.WalletDaoImpl;
import com.cg.exception.WalletApplicationException;
/**
 * @author vmummala
 */
public class WalletServiceImpl implements IWalletService {

	private static IWalletDao iWalletDao = new WalletDaoImpl();
	
	public Customer createAccount(Customer customer) {
		
		return iWalletDao.createAccount(customer);
	}

	public double showBalance(int customerId) throws WalletApplicationException {
		
		return iWalletDao.showBalance(customerId);
	}

	public boolean deposit(int customerId, double amount)  throws WalletApplicationException {
		
		return iWalletDao.deposit(customerId, amount);
	}

	public boolean withdraw(int customerId, double amount) throws WalletApplicationException {
		
		return iWalletDao.withdraw(customerId, amount);
	}

	public boolean fundTransfer(int customerId, double amount) throws WalletApplicationException {
		
		return iWalletDao.fundTransfer(customerId, amount);
	}

	public List<Transaction> printTransaction(int customerId) {
		
		return iWalletDao.printTransaction(customerId);
	}

}
