package com.cg.ui;

import java.util.List;
import java.util.Scanner;

import com.cg.bean.Account;
import com.cg.bean.Customer;
import com.cg.bean.Transaction;
import com.cg.exception.WalletApplicationException;
import com.cg.service.IWalletService;
import com.cg.service.WalletServiceImpl;

public class Client {

	static IWalletService iWalletService;
	public static int customersId;
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		iWalletService = new WalletServiceImpl();
		System.out.println("1.Create account 2.Login");
		int option = scanner.nextInt();
		
		switch(option) {
		case 1:{
			System.out.println("Enter your name");
			String customerName = scanner.next();
			System.out.println("Enter your Date of birth");
			String dateOfBirth = scanner.next();
			System.out.println("Enter phone number");
			String phone  = scanner.next();
			System.out.println("Enter email");
			String email  = scanner.next();
			System.out.println("Enter address");
			String address  = scanner.next();
			int customerId = (int) (Math.random()*1000); 
			
			long accountNo = (long) (Math.random()*100000); 
			double balance = 0.0;
			Account account = new Account(accountNo,balance);
			 
			Customer customer = new Customer(customerId,customerName,dateOfBirth,phone,email,address,account,null);
			Customer createdCustomer = iWalletService.createAccount(customer);
		
			System.out.println("Account created succesfully!! Your  customer id is "+createdCustomer.getCustomerId());
			String o = null;
			customersId = createdCustomer.getCustomerId();
			do {
			System.out.println("1.show balance\n2.deposit\n3.withdraw\n4.fundtransfer\n5.printtransaction");
			int opt = scanner.nextInt();
			switch(opt) {
			case 1:{
				System.out.println("enter customer id");
				int custId = scanner.nextInt();
				try {
					System.out.println("Your balance is "+iWalletService.showBalance(custId));
				} catch (WalletApplicationException e) {
				
					e.printStackTrace();
				}
			}break;
			case 2:{
				System.out.println("enter your customer id and amount you want to deposit");
				int custId = scanner.nextInt();
				double amount = scanner.nextDouble();
				try {
					if(iWalletService.deposit(custId, amount))
							System.out.println("amount deposited successfully");
					else 
						System.out.println("error occured");
				} catch (WalletApplicationException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}break;
			case 3:{
				System.out.println("enter your customer id and amount you want to withdraw");
				int custId = scanner.nextInt();
				double amount = scanner.nextDouble();
				try {
					if(iWalletService.withdraw(custId, amount)) {
						System.out.println("amount withdrawed succesfully");
					}
					
				} catch (WalletApplicationException e) {
					
					e.printStackTrace();
				}
			}break;
			case 4:{
				System.out.println("Enter benificiary cutomer id and amount you want to transfer");
				int custId = scanner.nextInt();
				double amount = scanner.nextDouble();
				try {
					iWalletService.fundTransfer(custId, amount);
				} catch (WalletApplicationException e) {
					
					e.printStackTrace();
				}
				
			}break;
			case 5:{
				System.out.println("Enter customer id");
				int custId = scanner.nextInt();
				List<Transaction> transationList =iWalletService.printTransaction(custId);
			    for(Transaction transaction:transationList) {
			    	if(transaction.getTransactionType().equals("fund transfered"))
			    		System.out.println("Amount "+transaction.getAmount() +" " +transaction.getTransactionType()+" to customerId"+transaction.getToAccountNo()+" with transaction id "+transaction.getTransactionId()+" at "+transaction.getTransactionDate());
			    	else
			    	System.out.println("Amount "+transaction.getAmount() +" " +transaction.getTransactionType()+" with transaction id "+transaction.getTransactionId()+" at "+transaction.getTransactionDate());
			    }
			}
			}
			System.out.println("Press y to continue");
			o = scanner.next();
			}while(o.equalsIgnoreCase("y"));
			System.out.println("Thank You");
			
		}break;
		case 2:{
			//implementation for login
		}
		}

		scanner.close();
	}

}
