package com.cg.bean;

import java.util.List;

public class Customer {

	int customerId;
	String customerName;
	String dateOfBirth;
	String phone;
	String email;
	String address;
	Account account;
	List<Transaction> transationList;
	public Customer(int customerId, String customerName, String dateOfBirth, String phone, String email,
			String address, Account account, List<Transaction> transationList) {
		super();
		this.customerId = customerId;
		this.customerName = customerName;
		this.dateOfBirth = dateOfBirth;
		this.phone = phone;
		this.email = email;
		this.address = address;
		this.account = account;
		this.transationList = transationList;
	}
	public int getCustomerId() {
		return customerId;
	}
	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public String getDateOfBirth() {
		return dateOfBirth;
	}
	public void setDateOfBirth(String dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public Account getAccount() {
		return account;
	}
	public void setAccount(Account account) {
		this.account = account;
	}
	public List<Transaction> getTransationList() {
		return transationList;
	}
	public void setTransationList(List<Transaction> transationList) {
		this.transationList = transationList;
	}
	
	

}
