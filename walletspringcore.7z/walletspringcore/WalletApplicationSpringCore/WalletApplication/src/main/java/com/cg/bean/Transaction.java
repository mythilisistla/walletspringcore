package com.cg.bean;

import java.util.Date;

public class Transaction {

	int transactionId;
	String transactionType;
	Date transactionDate;
	long toAccountNo;
	double amount;
	
	
	public Transaction() {
		super();
		
	}


	public Transaction(int transactionId, String transactionType, Date transactionDate, long toAccountNo,
			double amount) {
		super();
		this.transactionId = transactionId;
		this.transactionType = transactionType;
		this.transactionDate = transactionDate;
		this.toAccountNo = toAccountNo;
		this.amount = amount;
	}


	public int getTransactionId() {
		return transactionId;
	}


	public void setTransactionId(int transactionId) {
		this.transactionId = transactionId;
	}


	public String getTransactionType() {
		return transactionType;
	}


	public void setTransactionType(String transactionType) {
		this.transactionType = transactionType;
	}


	public Date getTransactionDate() {
		return transactionDate;
	}


	public void setTransactionDate(Date transactionDate) {
		this.transactionDate = transactionDate;
	}


	public long getToAccountNo() {
		return toAccountNo;
	}


	public void setToAccountNo(long toAccountNo) {
		this.toAccountNo = toAccountNo;
	}


	public double getAmount() {
		return amount;
	}


	public void setAmount(double amount) {
		this.amount = amount;
	}
	
	

}
